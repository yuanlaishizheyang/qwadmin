
# QWadmin
基于thinkphp与aceadmin模板的后台管理系统

**===============================安装说明================================**



1.`sql.sql`文件导入到数据库中。

2.在文件`App/Common/Conf/db.php`设置数据库相关信息

3.在文件`App/Common/Conf/config.php`设置`COOKIE_SALT`。

4.配置完成

> 后台地址：http://www.example.com/index.php/Qwadmin/  

> 账号admin  密码 admin

**=============================相关信息====================================**

**演示地址**：http://demo.qwadmin.qiawei.com/index.php/Qwadmin/  账号admin  密码 admin

**官网地址**：http://qwadmin.qiawei.com/

**QQ交流群**：231272191

欢迎大家有进行沟通交流！

开源是一种精神！为中国的互联网行业发展献出一份小小的力量~~

**==================================后台截图==================================**

![image](https://github.com/qiaweicom/qwadmin/raw/master/screenshots/login.png)

![image](https://github.com/qiaweicom/qwadmin/raw/master/screenshots/index.png)

![image](https://github.com/qiaweicom/qwadmin/raw/master/screenshots/person.png)

![image](https://github.com/qiaweicom/qwadmin/raw/master/screenshots/member.png)

![image](https://github.com/qiaweicom/qwadmin/raw/master/screenshots/group.png)

![image](https://github.com/qiaweicom/qwadmin/raw/master/screenshots/Database.png)

![image](https://github.com/qiaweicom/qwadmin/raw/master/screenshots/new_add.png)

![image](https://github.com/qiaweicom/qwadmin/raw/master/screenshots/links.png)

![image](https://github.com/qiaweicom/qwadmin/raw/master/screenshots/menu.png)